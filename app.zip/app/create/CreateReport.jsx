export default function CreateReport() {
  return (
    <View>
      <Text>Create Report</Text>
    </View>
  );
}
